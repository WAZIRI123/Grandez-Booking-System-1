<div class="flex flex-col">
    <div class="overflow-x-auto">
        <div class="inline-block py-2 min-w-full">
            <div class="overflow-hidden rounded-lg">
                <table class="min-w-full">
                    {{ $slot }}
                </table>
            </div>
        </div>
    </div>
</div>