<?php return array (
  'activity.index' => 'App\\Http\\Livewire\\Activity\\Index',
  'activity.show' => 'App\\Http\\Livewire\\Activity\\Show',
  'car.index' => 'App\\Http\\Livewire\\Car\\Index',
  'car.show' => 'App\\Http\\Livewire\\Car\\Show',
  'dashboard.admin.index' => 'App\\Http\\Livewire\\Dashboard\\Admin\\Index',
  'dashboard.user.index' => 'App\\Http\\Livewire\\Dashboard\\User\\Index',
  'dashboard.user.reservation.index' => 'App\\Http\\Livewire\\Dashboard\\User\\Reservation\\Index',
  'index' => 'App\\Http\\Livewire\\Index',
  'package.index' => 'App\\Http\\Livewire\\Package\\Index',
  'package.show' => 'App\\Http\\Livewire\\Package\\Show',
  'transfer.index' => 'App\\Http\\Livewire\\Transfer\\Index',
);